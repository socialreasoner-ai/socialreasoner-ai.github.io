CPS (source dataset label: ClimateChange)

Vlasceanu et al. (2024), Addressing climate change with behavioral science: A global intervention tournament in 63 countries.
https://doi.org/10.1126/sciadv.adj5778
Authors’ study data: https://zenodo.org/records/10345806

SocialReasoner website release, November 24, 2026. Each UTF-8 JSONL row records one person's answer to one question. train.jsonl and test.jsonl preserve the supplied training and test assignments and row order. Each participant has one dataset-specific public pseudonym in person_id and belongs to one split.

profile contains the respondent attributes. prompt is the supplied survey prompt. option maps each option ID to its label. groundtruth_id and groundtruth give the observed option ID and label.

train.jsonl: 24,111 records, 2,679 respondents
test.jsonl: 6,030 records, 670 respondents
Questions: 9
