ClimateChange (CPS)

Vlasceanu et al. (2024), Addressing climate change with behavioral science: A global intervention tournament in 63 countries.
https://doi.org/10.1126/sciadv.adj5778
Authors’ study data: https://zenodo.org/records/10345806

SocialReasoner evaluation data derived from Prompt v3 (November 18, 2026). Each UTF-8 JSONL row is one respondent’s answer to one survey question. The prompt field contains the full model input, including study material where applicable. The option field maps option IDs to their labels. groundtruth_id and answer contain the observed option ID. The question field preserves the source wording.

The original respondent-level 80/20 training and test assignments (seed 42) are preserved. Each respondent has one release-specific pseudonym and appears in a single split. All observations for each split are in one file. Source identifiers and local file paths are omitted.

train.jsonl: 287,496 records, 31,944 respondents
test.jsonl: 71,883 records, 7,987 respondents
Questions: 9
