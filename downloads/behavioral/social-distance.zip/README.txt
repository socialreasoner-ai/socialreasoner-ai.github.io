SocialDistance (SDI)

Legate, Nguyen, Weinstein et al., Psychological Science Accelerator Self-Determination Theory Collaboration (2022), A global experiment on motivating social distancing during the COVID-19 pandemic.
https://doi.org/10.1073/pnas.2111091119
Authors’ study data: https://osf.io/fc9y7/

SocialReasoner evaluation data derived from Prompt v3 (November 18, 2026). Each UTF-8 JSONL row is one respondent’s answer to one survey question. The prompt field contains the full model input, including study material where applicable. The option field maps option IDs to their labels. groundtruth_id and answer contain the observed option ID. The question field preserves the source wording.

The original respondent-level 80/20 training and test assignments (seed 42) are preserved. Each respondent has one release-specific pseudonym and appears in a single split. All observations for each split are in one file. Source identifiers and local file paths are omitted.

train.jsonl: 14,128 records, 3,532 respondents
test.jsonl: 3,532 records, 883 respondents
Questions: 4
