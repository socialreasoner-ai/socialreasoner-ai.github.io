SDI (source dataset label: SocialDistancing)

Legate, Nguyen, Weinstein et al., Psychological Science Accelerator Self-Determination Theory Collaboration (2022), A global experiment on motivating social distancing during the COVID-19 pandemic.
https://doi.org/10.1073/pnas.2111091119
Authors’ study data: https://osf.io/fc9y7/

SocialReasoner website release, November 24, 2026. Each UTF-8 JSONL row records one person's answer to one question. train.jsonl and test.jsonl preserve the supplied training and test assignments and row order. Each participant has one dataset-specific public pseudonym in person_id and belongs to one split.

profile contains the respondent attributes. prompt is the supplied survey prompt. option maps each option ID to its label. groundtruth_id and groundtruth give the observed option ID and label.

train.jsonl: 4,888 records, 1,222 respondents
test.jsonl: 1,224 records, 306 respondents
Questions: 4
