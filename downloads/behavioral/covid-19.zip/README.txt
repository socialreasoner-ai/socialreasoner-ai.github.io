COVID-19 (VAPP)

Lazarus et al. (2024), Influence of COVID-19 on trust in routine immunization, health information sources and pandemic preparedness in 23 countries in 2023.
https://doi.org/10.1038/s41591-024-02939-2
Authors’ study data: https://doi.org/10.5281/zenodo.10568581

SocialReasoner evaluation data derived from Prompt v3 (November 18, 2026). Each UTF-8 JSONL row is one respondent’s answer to one survey question. The prompt field contains the full model input, including study material where applicable. The option field maps option IDs to their labels. groundtruth_id and answer contain the observed option ID. The question field preserves the source wording.

The original respondent-level 80/20 training and test assignments (seed 42) are preserved. Each respondent has one release-specific pseudonym and appears in a single split. All observations for each split are in one file. Source identifiers and local file paths are omitted.

train.jsonl: 108,684 records, 18,467 respondents
test.jsonl: 27,157 records, 4,617 respondents
Questions: 6
