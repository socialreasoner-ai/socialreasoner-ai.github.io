VAPP (source dataset label: CUNY2023-COVID19-perceived)

Lazarus et al. (2024), Influence of COVID-19 on trust in routine immunization, health information sources and pandemic preparedness in 23 countries in 2023.
https://doi.org/10.1038/s41591-024-02939-2
Authors’ study data: https://doi.org/10.5281/zenodo.10568581

SocialReasoner website release, November 24, 2026. Each UTF-8 JSONL row records one person's answer to one question. train.jsonl and test.jsonl preserve the supplied training and test assignments and row order. Each participant has one dataset-specific public pseudonym in person_id and belongs to one split.

profile contains the respondent attributes. prompt is the supplied survey prompt. option maps each option ID to its label. groundtruth_id and groundtruth give the observed option ID and label.

train.jsonl: 108,675 records, 18,467 respondents
test.jsonl: 27,166 records, 4,617 respondents
Questions: 6
